#include <string>

extern std::string token;